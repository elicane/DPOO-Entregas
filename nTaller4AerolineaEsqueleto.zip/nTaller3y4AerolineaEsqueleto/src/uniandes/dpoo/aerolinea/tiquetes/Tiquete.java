package uniandes.dpoo.aerolinea.tiquetes;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class Tiquete 
{
	/**
	 * El cliente que compró el tiquete
	 */
	private Cliente cliente;
	
	
	/**
	 * El código para el tiquete, el cual debe ser único
	 */
	private String codigo;
	
	
	/**
	 * El valor que debió pagar el cliente por este tiquete
	 */
	private int tarifa;
	
	
	/**
	 * Este atributo indica si un tiquete ya fue usado o no
	 */
	private boolean usado;
	
	
	/**
	 * El vuelo en el que se usará el tiquete
	 */
	private Vuelo vuelo;
	
	
	
	/**
	 * Crea un nuevo tiquete con los parámetros recibidos y se lo agrega al cliente que lo compró
	 */
	public Tiquete(String codigo, Vuelo vuelo, Cliente clienteComprador, int tarifa) 
	{
		this.codigo = codigo;
		this.vuelo = vuelo;
		this.cliente = clienteComprador;
		this.tarifa = tarifa;
		this.usado = false;
		
	}
	
	
	/**
	 * Methodes
	 */
	
	/**
	 * Indica si el tiquete ya fue usado
	 */
	public boolean esUsado()
	{
		return usado;
	}


	/**
	 * @return the cliente
	 */
	public Cliente getCliente() 
	{
		return cliente;
	}


	/**
	 * @return the codigo
	 */
	public String getCodigo() 
	{
		return codigo;
	}


	/**
	 * @return the tarifa
	 */
	public int getTarifa() 
	{
		return tarifa;
	}


	/**
	 * @return the vuelo
	 */
	public Vuelo getVuelo() 
	{
		return vuelo;
	}
	
	
	/**
	 * Cambia el estado del tiquete para marcarlo como usado
	 */
	public void marcarComoUsado() 
	{
		if (usado == false) 
		{
			usado = true;
		}
	}
}
