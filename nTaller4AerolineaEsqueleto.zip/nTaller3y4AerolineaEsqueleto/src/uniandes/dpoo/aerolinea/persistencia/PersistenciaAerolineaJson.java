package uniandes.dpoo.aerolinea.persistencia;

import java.io.File;
import java.nio.file.Files;
import java.util.Collection;
import java.util.LinkedList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import uniandes.dpoo.aerolinea.modelo.Aerolinea;
import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Avion;
import uniandes.dpoo.aerolinea.modelo.Ruta;

public class PersistenciaAerolineaJson implements IPersistenciaAerolinea
{
	/**
	 * Carga la información de todos los elementos de una aerolínea, excepto los clientes y tiquetes, 
	 * y actualiza la estructura de objetos que se encuentra dentro de la aerolínea
	 * @throws Exception 
	 */
	public void cargarAerolinea(String archivo, Aerolinea aerolinea) throws Exception 
	{
		String jsonCompleto = new String( Files.readAllBytes( new File( archivo ).toPath( ) ) );
        JSONObject raiz = new JSONObject( jsonCompleto );
        JSONArray vuelos = raiz.getJSONArray("vuelos");
        JSONArray aviones = raiz.getJSONArray("aviones");
        JSONArray rutas = raiz.getJSONArray("rutas");
        JSONArray aeropuertos = raiz.getJSONArray("Aeropuertos");
        List<Aeropuerto> Aeropuertos = new LinkedList<Aeropuerto>();
        for (int i=0;i<aviones.length();i++) 
        {
        	JSONObject Javion = aviones.getJSONObject(i);
        	String nombre = Javion.getString("nombre");
        	int capacidad = Javion.getInt("capacidad");
        	Avion avion = new Avion(nombre, capacidad);
        	aerolinea.agregarAvion(avion);
        }
        
        for (int i=0;i<aeropuertos.length();i++) 
        {
        	JSONObject Jaeropuerto = aeropuertos.getJSONObject(i);
        	String nombre = Jaeropuerto.getString("nombre");
        	String codigo = Jaeropuerto.getString("codigo");
        	String nombreCiudad = Jaeropuerto.getString("nombreCiudad");
        	double latitud = Jaeropuerto.getDouble("latitud");
        	double longitud = Jaeropuerto.getDouble("longitud");
        	Aeropuerto aeropuerto = new Aeropuerto(nombre, codigo, nombreCiudad, latitud, longitud);
        	Aeropuertos.add(aeropuerto);
        }
        
        for (int i=0;i<rutas.length();i++) 
        {
        	JSONObject Jruta = rutas.getJSONObject(i);
        	JSONObject Jorigen = Jruta.getJSONObject("origen");
        	JSONObject Jdestino = Jruta.getJSONObject("destino");
        	Aeropuerto origen = null;
        	Aeropuerto destino = null;
        	for (int a=0; a<Aeropuertos.size(); a++) 
        	{
        		Aeropuerto aeropuerto = Aeropuertos.get(a);
        		if (aeropuerto.equals(Jorigen)) 
        		{
        			origen = aeropuerto;
        		}
        		else if (aeropuerto.equals(Jdestino)) 
        		{
        			destino = aeropuerto;
        		}
        	}
        	String horaSalida = Jruta.getString("horaSalida");
        	String horaLlegada = Jruta.getString("horaLlegada");
        	String codigoRuta = Jruta.getString("codigoRuta");
        	
			Ruta ruta = new Ruta(origen, destino, horaSalida, horaLlegada, codigoRuta);
        	aerolinea.agregarRuta(ruta);
        }
        
        for (int i=0;i<vuelos.length();i++) 
        {
        	JSONObject Jvuelo = vuelos.getJSONObject(i);
        	JSONObject Jruta = Jvuelo.getJSONObject("ruta");
        	String fecha = Jvuelo.getString("fecha");
        	JSONObject Javion = Jvuelo.getJSONObject("avion");
        	Collection<Ruta> Rutas = aerolinea.getRutas();
        	Object[] Arutas = new Object[] {};
        	Arutas = Rutas.toArray();
        	List<Avion> Aviones = (List<Avion>) aerolinea.getAviones();
        	String codruta = null;
        	String nombreavion = null;
        	for (int a=0; a<Arutas.length; a++) 
        	{
        		Object Oruta = Arutas[a];
        		if (Jruta.equals(Oruta)) 
        		{
        			Ruta cast = (Ruta) Oruta;
        			codruta = cast.getCodigoRuta();
        		}
        	}
        	for (int a=0; a<Aviones.size(); a++) 
        	{
        		Avion Oavion = Aviones.get(a);
        		if (Javion.equals(Oavion)) 
        		{
        			nombreavion = Oavion.getNombre();
        		}
        	}
        	aerolinea.programarVuelo(fecha, codruta, nombreavion);
        }
        	
	}
	
	
	
	/**
	 * Salva en un archivo la información de todos los elementos de una aerolínea, excepto los clientes y tiquetes
	 */
	public void salvarAerolinea(String archivo, Aerolinea aerolinea) 
	{
		
	}
}
