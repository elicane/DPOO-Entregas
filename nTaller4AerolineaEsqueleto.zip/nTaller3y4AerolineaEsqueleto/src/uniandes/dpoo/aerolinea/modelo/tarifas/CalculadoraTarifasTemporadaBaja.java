package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.cliente.ClienteCorporativo;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas
{
	/**
	 * El costo por kilómetro en temporada baja para clientes corporativos
	 */
	protected int COSTO_POR_KM_CORPORATIVO = 900;
	
	/**
	 * El costo por kilómetro en temporada baja para personas naturales
	 */
	protected int COSTO_POR_KM_NATURAL = 600;
	
	/**
	 * El descuento que se le puede aplicar a empresas grandes
	 */
	protected double DESCUENTO_GRANDES = 0.2;
	
	/**
	 * El descuento que se le puede aplicar a empresas medianas
	 */
	protected double DESCUENTO_MEDIANAS = 0.1;
	
	/**
	 * El descuento que se le puede aplicar a empresas pequeñas
	 */
	protected double DESCUENTO_PEQ = 0.02;
	
	
	
	/**
	 * Methodes
	 */


	/**
	 * Calcula el costo base como COSTO_POR_KM x distancia.
	 */
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) 
	{
		String tipo = cliente.getTipoCliente();
		Ruta ruta = vuelo.getRuta();
		Aeropuerto aeropuerto1 = ruta.getOrigen();
		Aeropuerto aeropuerto2 = ruta.getDestino();
		int distancia = Aeropuerto.calcularDistancia(aeropuerto1, aeropuerto2);
		int costoXkm = 0;
		if (tipo.equalsIgnoreCase("Natural"))
		{
			costoXkm = distancia * COSTO_POR_KM_NATURAL;
		}
		else if (tipo.equalsIgnoreCase("Corporativo"))
		{
			costoXkm = distancia * COSTO_POR_KM_CORPORATIVO;
		}
		return costoXkm;
	}


	/**
	 * Calcula el porcentaje de descuento que se le debería dar a un cliente dado su tipo y/o su historia.
	 */
	protected double calcularPorcentajeDescuento(Cliente cliente) 
	{
		double descuento = 0;
		String tipo = cliente.getTipoCliente();
		if (tipo.equalsIgnoreCase("Natural"))
		{
			descuento = 0;
		}
		else if (tipo.equalsIgnoreCase("Corporativo")) 
		{
			
		}
		
		return 0;
	}
	
}
