package uniandes.dpoo.aerolinea.modelo.tarifas;

import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Aeropuerto;
import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class CalculadoraTarifas 
{
	/**
	 * El porcentaje que corresponde al impuesto sobre la costo base
	 */
	public static double IMPUESTO = 0.28;
	
	/**
	 * Methodes
	 */
	
	/**
	 * Este método calcula cuál debe ser la tarifa total para un vuelo, dado el vuelo y el cliente.
	 */
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) 
	{
		List<Tiquete> tiquetes = (List<Tiquete>) vuelo.getTiquetes();
		int tarifai = 0;
		for (int i=0;i<tiquetes.size();i++) 
		{
			Tiquete tiquete = tiquetes.get(i);
			if ((tiquete.getCliente()).equals(cliente)) 
			{
				int costo = tiquete.getTarifa();
			}
		}
		return -1;
	}
	
	
	
	/**
	 * Este método calcula cuál debe ser el costo base dado el vuelo y el cliente.
	 */
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	
	
	/**
	 * Calcula la distancia aproximada en kilómetros para una ruta
	 */
	protected int calcularDistanciaVuelo(Ruta ruta) 
	{	
		Aeropuerto aeropuerto1 = ruta.getOrigen();
		Aeropuerto aeropuerto2 = ruta.getDestino();
		return Aeropuerto.calcularDistancia(aeropuerto1, aeropuerto2);
	}
	
	
	
	/**
	 * Calcula el porcentaje de descuento que se le debería dar a un cliente dado su tipo y/o su historia.
	 */
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	
	
	/**
	 * Calcula el valor de los impuestos para un tiquete, dado el costo base.
	 */
	protected int calcularValorImpuestos(int costoBase) 
	{
		return (int)(costoBase*IMPUESTO);
	}
	
	
	
}
