package uniandes.dpoo.aerolinea.modelo;

public class Avion 
{
	/**Atributos**/
	
	/**
	 * La El nombre con el que se identifica el avion
	 */
	private String nombre;
	

	/**
	 * La capacidad del avion
	 */
	private int capacidad;
	
	
	/**
	 * Construye un avión con un determinado nombre y capacidad
	 */
	public Avion(String nombre, int capacidad) 
	{
		this.nombre = nombre;
		this.capacidad = capacidad;
	}

	/**Methodes**/
	
	
	/**
	 * @return the nombre
	 */
	public String getNombre() 
	{
		return nombre;
	}


	/**
	 * @return the capacidad
	 */
	public int getCapacidad() 
	{
		return capacidad;
	}
	
	
	
	
}
