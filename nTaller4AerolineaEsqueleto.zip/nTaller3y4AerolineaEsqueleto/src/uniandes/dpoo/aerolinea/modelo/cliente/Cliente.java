package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.LinkedList;
import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente 
{
	/**
	 * La lista de tiquetes sin usar del cliente
	 */
	private List<Tiquete> tiquetesSinUsar;
	
	/**
	 * La lista de tiquetes usados del cliente
	 */
	private List<Tiquete> tiquetesUsados;
	
	/**
	 * Inicializa las listas de tiquetes del cliente.
	 */
	public Cliente() 
	{
		tiquetesSinUsar = new LinkedList<Tiquete>();
		tiquetesUsados = new LinkedList<Tiquete>();
	}
	
	
	/**
	 * Agrega un nuevo tiquete a la lista de tiquetes (sin usar) que ha comprado el cliente
	 */
	public void agregarTiquete(Tiquete tiquete) 
	{
		tiquetesSinUsar.add(tiquete);
	}
	


	/**
	 * Calcula el valor total de los tiquetes que ha comprado un cliente
	 */
	public int calcularValorTotalTiquetes() 
	{
		int sizeSinUsar = tiquetesSinUsar.size(); 
		int sizeUsado = tiquetesUsados.size();
		int total = 0;
		for (int i = 0; i < sizeSinUsar; i++) 
		{
			Tiquete tiquete = tiquetesSinUsar.get(i);
			int tarifa = tiquete.getTarifa();
			total =+ tarifa;
		}
		
		for (int i = 0; i < sizeUsado; i++) 
		{
			Tiquete tiquete = tiquetesUsados.get(i);
			int tarifa = tiquete.getTarifa();
			total =+ tarifa;
		}
		
		return total;
	}
	
	
	
	/**
	 * Retorna el identificador del cliente
	 */
	public abstract String getIdentificador();
	
	
	
	/**
	 * Retorna el tipo del cliente.
	 */
	public abstract String getTipoCliente();
	
	
	
	
	/**
	 * Marca como usados todos los tiquetes del cliente qus se hayan realizado en el vuelo que llega por parámetro, 
	 * moviéndolos de la lista de tiquetes sin usar a la lista de tiquetes usados
	 */
	public void usarTiquetes(Vuelo vuelo) 
	{
		int sizetiquetes = tiquetesSinUsar.size();
		for (int i=0; i<sizetiquetes ;i++) 
		{
			Tiquete tiquete = tiquetesSinUsar.get(i);
			if ((tiquete.getVuelo()).equals(vuelo)) 
			{
				tiquete.marcarComoUsado();
				tiquetesSinUsar.remove(i);
				tiquetesUsados.add(tiquete);
			}
		}
	}
}	
