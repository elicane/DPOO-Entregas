package uniandes.dpoo.aerolinea.modelo;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo 
{
	/**
	 * El avión utilizado para realizar el vuelo
	 */
	private Avion avion;
	
	/**
	 * La fecha para el vuelo, expresada como una cadena de la forma YYYY-MM-DD
	 */
	private String fecha;
	
	
	private Ruta ruta;
	
	/**
	 * Los tiquetes que ya fueron vendidos para el vuelo
	 */
	private Map<String, Tiquete> tiquetes = new HashMap<String, Tiquete>();
	
	
	/**
	 * Crea un nuevo vuelo con los parámetros dados
	 */
	public Vuelo(Ruta ruta, String fecha, Avion avion) 
	{
		this.ruta = ruta;
		this.fecha = fecha;
		this.avion = avion;
	}

	/**
	 * Methodes
	 */

	/**
	 * @return the avion
	 */
	public Avion getAvion() 
	{
		return avion;
	}


	/**
	 * @return the fecha
	 */
	public String getFecha() 
	{
		return fecha;
	}


	/**
	 * @return the ruta
	 */
	public Ruta getRuta() 
	{
		return ruta;
	}


	/**
	 * @return the tiquetes
	 */
	public Collection<Tiquete> getTiquetes() 
	{
		Collection<Tiquete> Ltiquetes = this.tiquetes.values();
		Tiquete[] arrTiquetes = (Tiquete[]) Ltiquetes.toArray();
		List<Tiquete> tiquetes = new ArrayList<Tiquete>();
		for (int i=0;i<arrTiquetes.length;i++) 
		{
			tiquetes.add(arrTiquetes[i]);
		}
		return tiquetes;
	}
	
	/**
	 * Vende una determinada cantidad de tiquetes para el vuelo y los deja registrados en el mapa de tiquetes
	 */
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad)
	{
		return -1;
	}	
	
	public boolean equals​(Object obj) 
	{
		return false;
	}
}
