package uniandes.dpoo.aerolinea.modelo;

import java.util.Collection;
import java.util.Map;

import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;
import uniandes.dpoo.aerolinea.modelo.tarifas.CalculadoraTarifas;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public class Vuelo 
{
	/**
	 * El avión utilizado para realizar el vuelo
	 */
	private Avion avion;
	
	/**
	 * La fecha para el vuelo, expresada como una cadena de la forma YYYY-MM-DD
	 */
	private String fecha;
	
	
	private Ruta ruta;
	
	/**
	 * Los tiquetes que ya fueron vendidos para el vuelo
	 */
	private Map<String, Tiquete> tiquetes;
	
	
	/**
	 * Crea un nuevo vuelo con los parámetros dados
	 */
	public Vuelo(Ruta ruta, String fecha, Avion avion) 
	{
		this.ruta = ruta;
		this.fecha = fecha;
		this.avion = avion;
	}

	/**
	 * Methodes
	 */

	/**
	 * @return the avion
	 */
	public Avion getAvion() 
	{
		return avion;
	}


	/**
	 * @return the fecha
	 */
	public String getFecha() 
	{
		return fecha;
	}


	/**
	 * @return the ruta
	 */
	public Ruta getRuta() 
	{
		return ruta;
	}


	/**
	 * @return the tiquetes
	 */
	public Collection<Tiquete> getTiquetes() 
	{
		return null;
	}
	
	/**
	 * Vende una determinada cantidad de tiquetes para el vuelo y los deja registrados en el mapa de tiquetes
	 */
	public int venderTiquetes(Cliente cliente, CalculadoraTarifas calculadora, int cantidad)
	{
		return -1;
	}	
	
	public boolean equals​(Object obj) 
	{
		return false;
	}
}
