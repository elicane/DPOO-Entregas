package uniandes.dpoo.aerolinea.modelo.cliente;

public class ClienteNatural extends Cliente 
{

	public static String NATURAL = "Natural";
	
	private String nombre;
	
	
	public ClienteNatural(String nombre) 
	{
		
	}
	
	
	
	/**
	 * Retorna el identificador del cliente
	 */
	public String getIdentificador() 
	{
		
		return null;
	}

	/**
	 * Retorna el tipo del cliente
	 */
	public String getTipoCliente() 
	{

		return null;
	}

}
