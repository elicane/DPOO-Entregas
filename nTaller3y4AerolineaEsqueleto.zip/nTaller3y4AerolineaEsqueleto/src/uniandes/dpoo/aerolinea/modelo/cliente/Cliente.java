package uniandes.dpoo.aerolinea.modelo.cliente;

import java.util.List;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.tiquetes.Tiquete;

public abstract class Cliente 
{
	/**
	 * La lista de tiquetes sin usar del cliente
	 */
	private List<Tiquete> tiquetesSinUsar;
	
	/**
	 * La lista de tiquetes usados del cliente
	 */
	private List<Tiquete> tiquetesUsados;
	
	/**
	 * Inicializa las listas de tiquetes del cliente.
	 */
	public Cliente() 
	{
		
	}
	
	
	/**
	 * Agrega un nuevo tiquete a la lista de tiquetes (sin usar) que ha comprado el cliente
	 */
	public void agregarTiquete(Tiquete tiquete) 
	{
		
	}
	


	/**
	 * Calcula el valor total de los tiquetes que ha comprado un cliente
	 */
	public int calcularValorTotalTiquetes() 
	{
		return -1;
	}
	
	
	
	/**
	 * Retorna el identificador del cliente
	 */
	public abstract String getIdentificador();
	
	
	
	/**
	 * Retorna el tipo del cliente.
	 */
	public abstract String getTipoCliente();
	
	
	
	
	/**
	 * Marca como usados todos los tiquetes del cliente qus se hayan realizado en el vuelo que llega por parámetro, 
	 * moviéndolos de la lista de tiquetes sin usar a la lista de tiquetes usados
	 */
	public void usarTiquetes(Vuelo vuelo) 
	{
		
	}
}	
