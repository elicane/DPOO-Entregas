package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Ruta;
import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public abstract class CalculadoraTarifas 
{
	/**
	 * El porcentaje que corresponde al impuesto sobre la costo base
	 */
	public static double IMPUESTO = 0.28;
	
	
	public CalculadoraTarifas() 
	{
		
	}
	
	/**
	 * Methodes
	 */
	
	/**
	 * Este método calcula cuál debe ser la tarifa total para un vuelo, dado el vuelo y el cliente.
	 */
	public int calcularTarifa(Vuelo vuelo, Cliente cliente) 
	{
		return -1;
	}
	
	
	
	/**
	 * Este método calcula cuál debe ser el costo base dado el vuelo y el cliente.
	 */
	protected abstract int calcularCostoBase(Vuelo vuelo, Cliente cliente);
	
	
	
	/**
	 * Calcula la distancia aproximada en kilómetros para una ruta
	 */
	protected int calcularDistanciaVuelo(Ruta ruta) 
	{
		return -1;
	}
	
	
	
	/**
	 * Calcula el porcentaje de descuento que se le debería dar a un cliente dado su tipo y/o su historia.
	 */
	protected abstract double calcularPorcentajeDescuento(Cliente cliente);
	
	
	
	/**
	 * Calcula el valor de los impuestos para un tiquete, dado el costo base.
	 */
	protected int calcularValorImpuestos(int costoBase) 
	{
		return -1;
	}
	
	
	
}
