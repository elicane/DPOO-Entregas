package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaAlta extends CalculadoraTarifas
{
	/**
	 * El costo por kilómetro para temporada alta
	 */
	protected int COSTO_POR_KM = 1000;
	
	
	
	
	/**
	 * Methodes
	 */
	
	/**
	 * Calcula el costo base como COSTO_POR_KM x distancia.
	 */
	public int calcularCostoBase(Vuelo vuelo, Cliente cliente) 
	{
		return -1;
	}
	

	/**
	 * Calcula el porcentaje de descuento que se le debería dar a un cliente dado su tipo y/o su historia.
	 */
	protected double calcularPorcentajeDescuento(Cliente cliente) 
	{
		
		return 0;
	}
	
}
