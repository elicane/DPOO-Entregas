package uniandes.dpoo.aerolinea.modelo.tarifas;

import uniandes.dpoo.aerolinea.modelo.Vuelo;
import uniandes.dpoo.aerolinea.modelo.cliente.Cliente;

public class CalculadoraTarifasTemporadaBaja extends CalculadoraTarifas
{
	/**
	 * El costo por kilómetro en temporada baja para clientes corporativos
	 */
	protected int COSTO_POR_KM_CORPORATIVO = 900;
	
	/**
	 * El costo por kilómetro en temporada baja para personas naturales
	 */
	protected int COSTO_POR_KM_NATURAL = 600;
	
	/**
	 * El descuento que se le puede aplicar a empresas grandes
	 */
	protected double DESCUENTO_GRANDES = 0.2;
	
	/**
	 * El descuento que se le puede aplicar a empresas medianas
	 */
	protected double DESCUENTO_MEDIANAS = 0.1;
	
	/**
	 * El descuento que se le puede aplicar a empresas pequeñas
	 */
	protected double DESCUENTO_PEQ = 0.02;
	
	
	
	/**
	 * Methodes
	 */


	/**
	 * Calcula el costo base como COSTO_POR_KM x distancia.
	 */
	protected int calcularCostoBase(Vuelo vuelo, Cliente cliente) 
	{
		
		return 0;
	}


	/**
	 * Calcula el porcentaje de descuento que se le debería dar a un cliente dado su tipo y/o su historia.
	 */
	protected double calcularPorcentajeDescuento(Cliente cliente) 
	{
		return 0;
	}
	
}
